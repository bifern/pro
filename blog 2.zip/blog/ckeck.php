<?php
session_start();
$input_g = $_POST['gName'];
$input_w = $_POST['password'];

include_once('connect.php');

$q ="SELECT * FROM gro WHERE " .
"gName ='".$input_g."' AND pwd ='".$input_w."' ";


$objQuery = mysqli_query($mysqli,$q);
$objResult = mysqli_fetch_array($objQuery);
if(!$objResult)

	{
		echo "Username and Password Incorrect!";

	}
	else
	{
//*** Go to Main page


			header("location:select.php");


	}

	mysqli_close($mysqli);
?>
