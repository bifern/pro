<?php

// Create connection
$con = new mysqli('localhost','root','root','pro');
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$gname = $_POST['gname'];
$stu1 = $_POST['namemember1'];
$stu2= $_POST['namemember2'];
$stu3 = $_POST['namemember3'];

$num1 = $_POST['studentid1'];
$num2 = $_POST['studentid2'];
$num3 = $_POST['studentid3'];
$email = $_POST['email'];

$passwd= $_POST['password'];
 //$passwd = md5($passwd);

$gpa = $_POST['gpa'];
$options = $_POST['options'];

// echo $num1;
// echo $num2;
// echo $num3;
// echo $stu1;
// echo $stu2;
// echo $stu3;
//
//
// $q="INSERT INTO gro (gName,email,GPA,pwd,duration)
// VALUES ('".$gname."','".$email."','".$gpa."','".$passwd."',$options)";
//
//
// $sql="INSERT INTO student (sum,s_name)
// VALUES ('".$num1."', '".$stu1."'),
//       ('".$num2."', '".$stu2."'),
//       ('".$num3."', '".$stu3."')";
//
//       if (!mysqli_query($con, $q))
//       {
//         echo 'Not Inserted';
//       }
//
//       else
//       {
//         echo 'Inserted';
//       }
//
//       if (!mysqli_query($con, $sql))
//       {
//         echo 'Not Inserted';
//       }
//
//       else
//       {
//         echo 'Inserted';
//       }


$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "pro";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // begin the transaction
    $conn->beginTransaction();
    // our SQL statements
    $conn->exec("INSERT INTO gro (gName,email,GPA,pwd,duration)
    VALUES ('".$gname."','".$email."','".$gpa."','".$passwd."',$options)");
    $conn->exec("INSERT INTO student (s_num,s_name)
    VALUES ('".$num1."', '".$stu1."'),('".$num2."', '".$stu2."'),('".$num3."', '".$stu3."')");


    // commit the transaction
    $conn->commit();
    header("Location: loginstudent.html");
    exit();
    }
catch(PDOException $e)
    {
    // roll back the transaction if something failed
    $conn->rollback();
    echo "Error: " . $e->getMessage();
    }

$conn = null;

?>
