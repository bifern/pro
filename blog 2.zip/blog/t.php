<?php $result = exec("python ass.py"); // ให้ปรับเปลี่ยนไปตามค่าที่ตั้งไว้ในระบบปฏิบัติการครับ 
print_r($result);
?>
