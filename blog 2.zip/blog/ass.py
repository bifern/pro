import copy
import random
import functools

# Registration statistics
# ITS400: 38, CSS400: 61 => total = 99
# Required number of topics: 99/2 =  49

# guys are student groups
guys = ['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7', 'G8', 'G9', 'G10',
        'G11', 'G12', 'G13', 'G14', 'G15', 'G16', 'G17', 'G18', 'G19', 'G20',
        'G21', 'G22', 'G23', 'G24', 'G25', 'G26', 'G27', 'G28', 'G29', 'G30',
        'G31', 'G32', 'G33', 'G34', 'G35', 'G36', 'G37', 'G38', 'G39', 'G40',
        'G41', 'G42', 'G43', 'G44', 'G45', 'G46', 'G47', 'G48', 'G49', 'G50']


#gals are topics
BU = ['BU1', 'BU2', 'BU3', 'BU4']
CN = ['CN1', 'CN2', 'CN3', 'CN4']
EN = ['EN1', 'EN2', 'EN3', 'EN4']
GS = ['GS1', 'GS2','GS3', 'GS4']
KW = ['KW1', 'KW2', 'KW3']
NH = ['NH1', 'NH2', 'NH3', 'NH4', 'NH5']
PA = ['PA1', 'PA2', 'PA3','PA4', 'PA5']
SM = ['SM1', 'SM2', 'SM3', 'SM4']
SU = ['SU1', 'SU2', 'SU3', 'SU4']
TH = ['TH1','TH2', 'TH3', 'TH4', 'TH5', 'TH6']
TT = ['TT1', 'TT2', 'TT3', 'TT4', 'TT5']
VS = ['VS1', 'VS2']

gals = BU +  CN +  EN  + GS + KW + NH + PA + SM + SU + TH + TT + VS


# each group is allowed to declare several topics as its preferred topics (up to 12 topics, at most 2 topics from the same faculty member?)

guyprefers = {
 'G1':  ['KW1','KW2','TH2','TH1','CN3','PA1','PA4','EN1','SU1'],
 'G2':  ['SU1','TH2','NH3','CN2','TH4','SU3','EN3','TT1','VS1'],
 'G3':  ['TH1', 'CN2', 'CN1', 'TH2', 'PA2', 'PA3', 'BU3'],
 'G4':  ['KW3', 'SU1', 'GS4', 'PA5', 'NH1', 'EN4', 'SU2', 'TH1', 'CN3', 'TH2', 'TT2', 'VS2'],
 'G5':  ['KW1', 'KW2', 'TH1', 'TH2', 'SU4', 'BU1', 'PA4'],
 'G6':  ['GS3', 'TH2', 'PA4', 'KW2', 'PA3'],
 'G7':  ['TH5','TH2','CN3','SU1','PA1','GS2','KW1','KW2','EN1','GS3','PA4','NH4'],
 'G8':  ['TH3', 'CN2', 'NH1', 'TH5', 'PA3', 'GS2', 'CN4', 'SU2', 'BU2', 'BU3'],
 'G9':  ['PA5','CN1','CN4','PA2','BU3','TH2','TH3','EN4','SU2','SU3','SM','GS4'],
 'G10': ['TH1','TH3','BU1','CN2','EN1','KW1','PA1','PA4','SU1','SU4','EN4','KW3'],
 'G11': ['TH1','TH3','KW1','KW2','EN1','GS3','PA1','PA4','BU1','SU1','CN3','EN4'],
 'G12':  ['EN1','KW1','KW2','CN4','GS3','TH1','NH4','SM1','CN2','PA2','TH2','BU3'],
 'G13':  ['TH2','TH3','GS2','KW1','KW3','SU1','SU2'],
 'G14':  ['SU2', 'TH2', 'TH5', 'PA3', 'BU3', 'SU1', 'CN2', 'EN1', 'KW1', 'KW2', 'PA1', 'GS3'],
 'G15':  ['GS2', 'GS3', 'NH4','TH5'],
 'G16':  ['TH3', 'NH1', 'EN1', 'CN3', 'NH4', 'PA1', 'GS3', 'SU4', 'SU1', 'EN2', 'PA3', 'TH5'],
 'G17':  ['CN2', 'CN4', 'GS2', 'EN1', 'KW1' , 'KW2', 'SM1' , 'SU2' , 'TH4' , 'BU2' , 'BU3' , 'GS4'],
 'G18':  ['SU1','SU2','CN4','BU1','PA2','TH3','EN1','GS3'],
 'G19':  ['TH1', 'TH3', 'CN3', 'PA1', 'PA4', 'GS2', 'GS3', 'KW2', 'EN1', 'SU1', 'SU4', 'BU1'],
 'G20':  ['TH1', 'CN1', 'BU2', 'CN3', 'PA3' , 'PA1', 'TH3', 'NH1', 'GS3', 'EN1', 'KW1', 'KW2'],
 'G21':  ['PA1','PA2','BU1', 'BU3','GS3','TH1','KW1','EN1','KW2','SM1','SU4','CN1'],
 'G22':  ['TT3', 'GS4', 'PA4', 'PA5', 'KW3', 'EN4', 'SU1', 'TH3', 'NH4', 'NH1', 'GS3', 'SU2'],
 'G23':  ['SU4', 'NH2','CN2','NH4','PA1','BU1','TH1','KW1','TH5','PA3'],
 'G24':  [ 'TH1', 'KW1', 'CN3', 'KW2' , 'NH3', 'TH3' ],
 'G25':  ['GS2', 'GS3', 'KW1', 'KW2','PA1', 'SU1','SU4','TH5','TH1','EN1'],
 'G26':  ['SU1','TH2','NH3','CN2','TH4','SU3','EN3','TT1','VS1'],
 'G27':  ['CN2', 'PA3', 'SM2', 'SM3', 'NH3', 'GS2', 'GS1', 'TT1', 'TT2', 'PA2', 'CN1', 'TH4'],
 'G28':  ['KW1','GS3','TH3','TH5','SU1','KW2','BU1','NH4','EN1','GS2','PA1','CN3'],
 'G29':  ['TT4', 'EN4', 'GS4', 'CN2', 'PA2', 'SU3', 'SM1' ,'TH4', 'BU2', 'BU3', 'NH3', 'SU1'],
 'G30':  ['TH1', 'NH4', 'NH1', 'TH2', 'TH3', 'NH3', 'GS3', 'KW2', 'PA1', 'SU1', 'SU4'],
 'G31':  ['SU3','SU2','TH1','GS3','EN4','GS2','EN1'],
 'G32':  ['PA2', 'PA5', 'GS4', 'CN4',  'SM1', 'EN4', 'KW3'],
 'G33':  ['TH2', 'CN2','BU2', 'SU2','GS4', 'PA4','SM3', 'KW3','EN1', 'TH1','EN4', 'PA3'],
 'G34':  ['NH1','SU1','SU2','BU1','BU2','GS3','TH2','EN1','PA4','KW1','CN3','NH3'],
 'G35':  ['GS1', 'KW1', 'SU1', 'BU1', 'EN1', 'GS2', 'PA1', 'SU3'],
 'G36':  ['GS1','GS2','EN1','CN3','KW1','TH3','SU4','PA1','NH3','PA3','TH1'],
 'G37':  ['SU1', 'TH1', 'GS3', 'CN3', 'SU4', 'TH3', 'NH4', 'EN1', 'PA1', 'BU1', 'NH1', 'KW1'],
 'G38':  ['TH5', 'TH2', 'BU1', 'KW1', 'PA1', 'GS2', 'CN3', 'BU3', 'GS3', 'NH1', 'CN4', 'KW2'],
 'G39':  ['CN1', 'CN4', 'PA2', 'PA4' , 'KW3'],
 'G40':  ['BU2','EN1','GS3','SU1','TH1','SU3','NH4','GS2','PA3','TT1','TT2'],
 'G41':  ['GS2', 'PA3', 'TH5', 'KW1', 'TH3', 'SU1', 'BU1', 'KW2', 'GS3', 'CN3', 'PA1', 'CN1'],
 'G42':  ['TH6', 'TH3', 'KW1', 'GS3', 'CN3', 'BU3' ,'EN2', 'PA5', 'KW3', 'SU1', 'NH1', 'SU2'],
 'G43':  ['TH2', 'GS3', 'TH3', 'KW1', 'TH1', 'CN3', 'BU2', 'GS1', 'SU4', 'EN1'],
 'G44':  ['SU1','SU4','BU1','KW1', 'KW2','EN1','NH1','NH4','PA1','TH1','GS4','GS2'],
 'G45':  ['TH3', 'TH1', 'KW1','KW2','BU1','SU1','SU4','EN1','PA1','GS1','GS3','CN3'],
 'G46':  ['PA5', 'PA1', 'SU1', 'SU3', 'EN1', 'GS3', 'CN3', 'GS2', 'NH4', 'KW3', 'BU1', 'NH1'],
 'G47':  ['TH3', 'GS2', 'GS3', 'EN1'],
 'G48':  ['SU3','SU2','PA4','PA5','KW3','BU2','CN3','CN1','BU3' ,'KW1','TH2','TH1'],
 'G49':  ['PA2', 'SM1', 'SU3', 'KW3', 'PA4', 'TT3', 'CN1', 'EN2', 'CN4', 'EN3', 'NH2', 'VS1'],
 'G50':  [ 'TH5', 'TH1' , 'PA2' , 'GS1' , 'CN3' , 'SU1' ]}


# filling missing preferences for groups
for guy in guys:
    listedGals = guyprefers[guy]
    missingGals = list(set(gals).difference(set(listedGals)))
    random.shuffle(missingGals)
    guyprefers[guy] =   guyprefers[guy]  +  missingGals


print("Filled group preferences")
for guy in guys:
    print(guy, "prefers", guyprefers[guy])
 


# attributes of each group
guyrecords = [{'groupID': 'G1', 'gpa': 2.96, 'duration': 2},
 {'groupID': 'G2', 'gpa': 3.11, 'duration': 2},
 {'groupID': 'G3', 'gpa': 2.62, 'duration': 2},
 {'groupID': 'G4', 'gpa': 2.6, 'duration': 2},
 {'groupID': 'G5', 'gpa': 3.28, 'duration': 2},
 {'groupID': 'G6', 'gpa': 2.5, 'duration': 2},
 {'groupID': 'G7', 'gpa': 3.075, 'duration': 1},
 {'groupID': 'G8', 'gpa': 3.395, 'duration': 1},
 {'groupID': 'G9', 'gpa': 2.955, 'duration': 2},
 {'groupID': 'G10','gpa': 2.46, 'duration': 2},
 {'groupID': 'G11', 'gpa': 3.345, 'duration': 1},
 {'groupID': 'G12', 'gpa': 3.21, 'duration': 1},
 {'groupID': 'G13', 'gpa': 2.7, 'duration': 2},
 {'groupID': 'G14', 'gpa': 3.05, 'duration': 2},
 {'groupID': 'G15', 'gpa': 3.345, 'duration': 2},
 {'groupID': 'G16', 'gpa': 2.85, 'duration': 2},
 {'groupID': 'G17', 'gpa': 2.35, 'duration': 2},
 {'groupID': 'G18', 'gpa': 2.295, 'duration': 2},
 {'groupID': 'G19', 'gpa': 3.395, 'duration': 1},
 {'groupID': 'G20', 'gpa': 2.16, 'duration': 2},
 {'groupID': 'G21', 'gpa': 2.17, 'duration': 2},
 {'groupID': 'G22', 'gpa': 3.43, 'duration': 1},
 {'groupID': 'G23', 'gpa': 2.57, 'duration': 2},
 {'groupID': 'G24', 'gpa': 2.37, 'duration': 2},
 {'groupID': 'G25', 'gpa': 3.36, 'duration': 1},
 {'groupID': 'G26', 'gpa': 1.93, 'duration': 1},
 {'groupID': 'G27', 'gpa': 3.54, 'duration': 2},
 {'groupID': 'G28', 'gpa': 2.73, 'duration': 2},
 {'groupID': 'G29', 'gpa': 2.25, 'duration': 2},
 {'groupID': 'G30', 'gpa': 2.445, 'duration': 2},
 {'groupID': 'G31', 'gpa': 2.515, 'duration': 2},
 {'groupID': 'G32', 'gpa': 2.48, 'duration': 2},
 {'groupID': 'G33', 'gpa': 2.69, 'duration': 2},
 {'groupID': 'G34', 'gpa': 2.51, 'duration': 2},
 {'groupID': 'G35', 'gpa': 2.25, 'duration': 2},
 {'groupID': 'G36', 'gpa': 3.425, 'duration': 1},
 {'groupID': 'G37', 'gpa': 3.025, 'duration': 2},
 {'groupID': 'G38', 'gpa': 2.46, 'duration': 2},
 {'groupID': 'G39', 'gpa': 2.42, 'duration': 2},
 {'groupID': 'G40', 'gpa': 2.275, 'duration': 2},
 {'groupID': 'G41', 'gpa': 2.29, 'duration': 2},
 {'groupID': 'G42', 'gpa': 2.85, 'duration': 1},
 {'groupID': 'G43', 'gpa': 2.085, 'duration': 2},
 {'groupID': 'G44', 'gpa': 2.47, 'duration': 2},
 {'groupID': 'G45', 'gpa': 2.475, 'duration': 2},
 {'groupID': 'G46', 'gpa': 2.9, 'duration': 2},
 {'groupID': 'G47', 'gpa': 2.155, 'duration': 2},
 {'groupID': 'G48', 'gpa': 2.25, 'duration': 2},
 {'groupID': 'G49', 'gpa': 2.8, 'duration': 2},
 {'groupID': 'G50', 'gpa': 2.16, 'duration': 2}]
              


# sort groups according to duration of project, then GPA
def guyCom(gY,gX):
    if (gX['duration']==gY['duration']):
        if (gX['gpa']>gY['gpa']):
            return 1
        elif (gX['gpa']==gY['gpa']):
            return 0
        else:
            return -1
    elif (gX['duration']==2):
        return 1
    else:
        return -1

sortedguyrecords = sorted(guyrecords, key=functools.cmp_to_key(guyCom))

print("group priorities!")
i=1
for record in sortedguyrecords:
    print(i, ".", record['groupID'])
    i=i+1
    #print(record)
    

prioritiesOfGuys = [g['groupID'] for g in sortedguyrecords]

## prioritiesOfGuys = ['G27', 'G15', 'G5', 'G2', 'G14', 'G37', 'G1', 'G9', 'G46', 'G16', 'G49', 'G28', 'G13', 'G33', 'G3', 'G4', 'G23', 'G31', 'G34', 'G6', 'G32', 'G45', 'G44', 'G10', 'G38', 'G30', 'G39', 'G24', 'G17', 'G18', 'G41', 'G40', 'G29', 'G35', 'G48', 'G21', 'G20', 'G50', 'G47', 'G43', 'G22', 'G36', 'G8', 'G19', 'G25', 'G11', 'G12', 'G7', 'G42', 'G26']

##print(prioritiesOfGuys)


galprefers = {}
for gal in gals:
    galprefers[gal]=prioritiesOfGuys


## Faculty-specific preferences
galprefers['CN1'] = ['G39','G27', 'G15', 'G5', 'G2', 'G14', 'G37', 'G1', 'G9', 'G46', 'G16', 'G49', 'G28', 'G13', 'G33', 'G3', 'G4', 'G23', 'G31', 'G34', 'G6', 'G32', 'G45', 'G44', 'G10', 'G38', 'G30', 'G24', 'G17', 'G18', 'G41', 'G40', 'G29', 'G35', 'G48', 'G21', 'G20', 'G50', 'G47', 'G43', 'G22', 'G36', 'G8', 'G19', 'G25', 'G11', 'G12', 'G7', 'G42', 'G26']

galprefers['GS2'] = ['G15', 'G27', 'G5', 'G2', 'G14', 'G37', 'G1', 'G9', 'G46', 'G16', 'G49', 'G28', 'G13', 'G33', 'G3', 'G4', 'G23', 'G31', 'G34', 'G6', 'G32', 'G45', 'G44', 'G10', 'G38', 'G30', 'G39', 'G24', 'G17', 'G18', 'G41', 'G40', 'G29', 'G35', 'G48', 'G21', 'G20', 'G50', 'G47', 'G43', 'G22', 'G36', 'G8', 'G19', 'G25', 'G11', 'G12', 'G7', 'G42', 'G26']

galprefers['TH6'] = ['G42', 'G27', 'G15', 'G5', 'G2', 'G14', 'G37', 'G1', 'G9', 'G46', 'G16', 'G49', 'G28', 'G13', 'G33', 'G3', 'G4', 'G23', 'G31', 'G34', 'G6', 'G32', 'G45', 'G44', 'G10', 'G38', 'G30', 'G39', 'G24', 'G17', 'G18', 'G41', 'G40', 'G29', 'G35', 'G48', 'G21', 'G20', 'G50', 'G47', 'G43', 'G22', 'G36', 'G8', 'G19', 'G25', 'G11', 'G12', 'G7', 'G26']


 
def check(engaged):
    inverseengaged = dict((v,k) for k,v in engaged.items())
    for she, he in engaged.items():
        shelikes = galprefers[she]
        shelikesbetter = shelikes[:shelikes.index(he)]
        helikes = guyprefers[he]
        helikesbetter = helikes[:helikes.index(she)]
        for guy in shelikesbetter:
            guysgirl = inverseengaged[guy]
            guylikes = guyprefers[guy]
            if guylikes.index(guysgirl) > guylikes.index(she):
                print("%s and %s like each other better than "
                      "their present partners: %s and %s, respectively"
                      % (she, guy, he, guysgirl))
                return False
        for gal in helikesbetter:
            girlsguy = engaged[gal]
            gallikes = galprefers[gal]
            if gallikes.index(girlsguy) > gallikes.index(he):
                print("%s and %s like each other better than "
                      "their present partners: %s and %s, respectively"
                      % (he, gal, she, girlsguy))
                return False
    return True
 
def matchmaker():
    guysfree = guys[:]
    engaged  = {}
    guyprefers2 = copy.deepcopy(guyprefers)
    galprefers2 = copy.deepcopy(galprefers)
    while guysfree:
        guy = guysfree.pop(0)
        guyslist = guyprefers2[guy]
        gal = guyslist.pop(0)
        fiance = engaged.get(gal)
        if not fiance:
            # She's free
            engaged[gal] = guy
            print("  %s and %s" % (guy, gal))
        else:
            # The bounder proposes to an engaged lass!
            galslist = galprefers2[gal]
            if galslist.index(fiance) > galslist.index(guy):
                # She prefers new guy
                engaged[gal] = guy
                print("  %s dumped %s for %s" % (gal, fiance, guy))
                if guyprefers2[fiance]:
                    # Ex has more girls to try
                    guysfree.append(fiance)
            else:
                # She is faithful to old fiance
                if guyslist:
                    # Look again
                    guysfree.append(guy)
    return engaged
 
 
print('\nEngagements:')
engaged = matchmaker()
 
print('\nAssigments:')
print('  ' + ',\n  '.join('%s is assigned to %s' % couple
                          for couple in sorted(engaged.items())))

print("======Verify the assignments======")
print('Engagement stability check PASSED'
      if check(engaged) else 'Engagement stability check FAILED')


print("======Assignment statistics per faculties======")

faculties = [{'ini': 'BU','Topics': BU},{'ini': 'CN', 'Topics': CN},{'ini': 'EN','Topics': EN},{'ini': 'GS','Topics': GS},
             {'ini': 'KW','Topics': KW},{'ini': 'NH','Topics': NH},{'ini': 'PA','Topics': PA},{'ini': 'SM','Topics': SM},
             {'ini': 'SU','Topics': SU},{'ini': 'TH','Topics': TH},{'ini': 'TT','Topics': TT},{'ini': 'VS','Topics': VS}]

for faculty in faculties:
    faculty['Groups']=[ ]
       
for topic,group in engaged.items():
    for faculty in faculties:
        if topic in faculty['Topics']:
            for guyrecord in guyrecords:
                if guyrecord['groupID']==group:
                    faculty['Groups'] =  faculty['Groups'] + [guyrecord]


for faculty in faculties:
    groups = faculty['Groups']
    gpalist = [group['gpa'] for group in groups]
    faculty['AGPA'] = sum(gpalist)/len(gpalist)
    numOf2semprojects = 0
    for group in groups:
        if group['duration']==2:
            numOf2semprojects = numOf2semprojects + 1
    faculty['num of 2-sem projects'] = numOf2semprojects

print("Averaged GPA distr:")

print("\n".join([str(falculty['ini']) + ":" + str(falculty['AGPA']) for falculty in faculties]))

import statistics

print("Standard deviation:" + str(statistics.stdev([falculty['AGPA'] for falculty in faculties])))

print()

print("Numbers of 2-sem projects distr:")

print("\n".join([str(falculty['ini']) + ":" + str(falculty['num of 2-sem projects'])for falculty in faculties]),end = " ")


print('\n\nSwapping two topics to introduce an error')
engaged[gals[0]], engaged[gals[1]] = engaged[gals[1]], engaged[gals[0]]
for gal in gals[:2]:
    print('  %s is now assigned to %s' % (gal, engaged[gal]))
print()
print('Engagement stability check PASSED'
      if check(engaged) else 'Engagement stability check FAILED')
