<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Free responsive blog template</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/icons.css">
      <link rel="stylesheet" href="css/responsee.css">

      <!-- CUSTOM STYLE -->
      <link rel="stylesheet" href="css/template-style.css">
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>
   </head>
   <body class="size-1140 align-content-left">
      <div class="line">
         <div id="content-wrapper">
            <!-- LEFT COLUMN -->
            <div class="s-12 m-4 l-3">
               <div class="logo-box">
                  <h1>SENIOR PROJECT</h1>
               </div>
               <div class="aside-nav">
                 <ul class="chevron">
                   <li><a href="home.php"><i class="icon-home"></i>Home</a></li>

                    <li>
                     <a><i class="icon-list"></i>Topics</a>
                       <ul class="nav nav-second-level">
                         <li><a href="about.html">Bunyarit Uyyanonvara</a></li>
                         <li><a href="about.html">Cholwich Nattee"</a></li>
                         <li><a href="about.html">Ekawit Nantajeewarawat</a></li>
                         <li><a href="about.html">Gun Srijuntongsiri</a></li>
                         <li><a href="about.html">Komwut Wipusitwarakun</a></li>
                         <li><a href="about.html">Nguyen Duy Hung</a></li>
                         <li><a href="about.html">Pakinee Aimmanee</a></li>
                         <li><a href="about.html">Stanislav Makhanov</a></li>
                         <li><a href="about.html">Sasiporn Usanavasin</a></li>
                         <li><a href="about.html">Teerayut Horanont</a></li>
                         <li><a href="about.html">Thanaruk Theeramunkong</a></li>
                         <li><a href="about.html">Virach Sornlertlamvanich</a></li>
                       </ul>
                    </li>

                    <?php
                    if($_SESSION['groupid'] == "Staff"){
                    ?>
                    <li>
                       <a><i class="icon-user"></i><?php echo $_SESSION['uname']?></a>
                       <ul class="nav nav-second-level">
                          <li><a href="loginstudent.html">STAFF</a></li>
                          <li><a href="add.php">Add Topics</a></li>
                          <li><a href="logout.php">Log Out</a></li>
                       </ul>
                    </li>

                  <?php }elseif($_SESSION['groupid'] == "Admin"){ ?>
                    <li>
                       <a><i class="icon-user"></i><?php echo $_SESSION['uname']?></a>
                       <ul class="nav nav-second-level">
                          <li><a href="loginstudent.html">ADMIN</a></li>
                          <li><a href="add.php">Add Topics</a></li>
                          <li><a href="logout.php">Log Out</a></li>
                       </ul>
                    </li>

                  <?php } else { ?>
                      "<li>
                         <a><i class="icon-user"></i>Sign in</a>
                         <ul class="nav nav-second-level">
                            <li><a href="loginstudent.html">Student</a></li>
                            <li><a href="loginstaff.html">Staff</a></li>
                         </ul>
                      </li>";
                    <?php } ?>

                 </ul>
               </div>
            </div>

            <!-- RIGHT COLUMN -->
            <div class="s-12 m-8 l-9">
              <div class="box">
                 <!-- HEADER -->

                    <section>
                       <h2>Registration</h2>
                       <hr>
                       <div class="line">
                          <form action="insert_reg.php" method="POST"class="customform">

                            <div class="margin">
                              <div class="s-12 l-6"><h5>Group Name</h5>
                                <input placeholder="Group name" title="Group name" type="text" name="gname" />
                              </div>
                            </div>


                             <article class="line">
                                <div class="margin">
                                  <div class="s-12 l-6">
                                    <h5>Member</h5>
                                  </div>
                                  <div class="s-12 l-6">
                                  <select name="menu1" onChange="MM_jumpMenu('parent',this,0)">
                                  <?php
                                  for($i=1;$i<=3;$i++)
                                  {
                                  	if($_GET["Line"] == $i)
                                  	{
                                  		$sel = "selected";
                                  	}
                                  	else
                                  	{
                                  		$sel = "";
                                  	}
                                  ?>
                                  	<option value="<?php echo $_SERVER["PHP_SELF"];?>?Line=<?php echo $i;?>" <?php echo $sel;?>><?php echo $i;?></option>
                                  <?php
                                  }
                                  ?>
                                  </select>
                                  </div>

                                  <?php
                                  $line = $_GET["Line"];
                                  if($line == 0){$line=1;}
                                  for($i=1;$i<=$line;$i++)
                                  {
                                  ?>
                                  <div class="s-12 l-6"><input name="namemember<?php echo $i;?>" placeholder="Name" title="Name" type="text" /></div>
                                  <div class="s-12 l-6"><input name="studentid<?php echo $i;?>" placeholder="ID" title="ID" type="text" /></div>

                                  <!-- <div class="s-12 l-6"><input name="namemember2" placeholder="Name" title="Name" type="text" /></div>
                                  <div class="s-12 l-6"><input name="studentid2" placeholder="ID" title="ID" type="text" /></div>

                                  <div class="s-12 l-6"><input name="namemember3" placeholder="Name" title="Name" type="text" /></div>
                                  <div class="s-12 l-6"><input name="studentid3" placeholder="ID" title="ID" type="text" /></div> -->
                                  <?php
                                  }
                                  ?>
                                </div>

                             <div class="line">
                                <div class="margin">
                                  <div class="s-12 l-6">
                                    <h5>Email</h5>
                                    <input name="email" placeholder="e-mail" title="e-mail" type="text" /></div>
                                </div>
                             </div>

                             <div class="margin">
                               <div class="s-12 l-6">
                                <h5>Password</h5>
                               <input type="password" name="password" placeholder="Password"id="password" maxlength="8">
                             </div>
                             </div>

                             <div class="line">
                               <div class="margin">
                                 <div class="s-12 l-6"><h5>Group averaged GPA</h5><input name="gpa" placeholder="GPA" title="GPA" type="text" /></div>
                                 <div class="s-12 l-6"> <h5>Project duration</h5>
                                   <input type="radio" name="options" id="optionsRadios1" value="1" checked /><label>1</label><br />
                                   <input type="radio" name="options" id="optionsRadios2" value="2"/><label>2</label>
                                 </div>
                               </div>
                            </div>

                             <div class="s-12 l-2 right"><button type="submit" value="Insert" >Submit</button></div>
                             <input type="hidden" name="hdnLine" value="<?php echo $i;?>">
                          </form>
                       </article>
                       </div>
                       </section>

              </div>

               <!-- FOOTER -->
               <div class="box footer">
                  <footer class="line">
                     <div class="s-12 l-6">
                        <p>Sirindhorn International Institute of Technology, Thammasat University</p>
                     </div>

                  </footer>
               </div>
            </div>
         </div>
      </div>
      <img id="background" class="hide-s" src="img/background.jpg" alt="">
      <script type="text/javascript" src="js/responsee.js"></script>

      <script language="JavaScript" type="text/JavaScript">
      <!--
      function MM_jumpMenu(targ,selObj,restore){ //v3.0
        eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
        if (restore) selObj.selectedIndex=0;
      }
      //-->
      </script>
   </body>
</html>
