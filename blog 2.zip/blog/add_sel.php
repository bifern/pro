<html>
<head>

<body>
<?php
	$objConnect = mysql_connect("localhost","root","root") or die("Error Connect to Database");
	$objDB = mysql_select_db("pro");

	for($i=1;$i<=$_POST["hdnLine"];$i++)
	{
		if($_POST["txttopic$i"] != "")
		{
			$strSQL = "INSERT INTO selection (topic) VALUES ('".$_POST["txttopic$i"]."') ";
			$objQuery = mysql_query($strSQL);

		}
	}

	echo "Save Done.";

mysql_close($objConnect);
?>
</body>
</html>
