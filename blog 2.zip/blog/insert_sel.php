<meta charset="utf-8" />
<?php
include('connect.php');

// print array ออกมาดู
print_r($_POST);

foreach($_POST['topic'] as $row=>$art){

$articles = mysql_real_escape_string($_POST['topic'][$row]);

$sql = "insert into insertmulti (topic) values ('$articles') ";

$result = mysqli_query($mysqli, $sql) or die ("Error in query: $sql " . mysqli_error());

}

mysqli_close($mysqli);

?>
